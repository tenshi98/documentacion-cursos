<?php
  $host = "localhost";
  $usuario = "root";
  $clave = "";
  $db = "escuela";
  //
  $conn = mysqli_connect($host, $usuario, $clave, $db) or die("Error");
  //
  $sql = "SELECT * FROM historicoTabular ORDER BY anio";
  //
  $r = mysqli_query($conn, $sql);
?>
<html>
<head>
  <title>Mandar una gráfica a PNG</title>
  <script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>
  <script type="text/javascript">
    google.charts.load("current", {packages:['corechart']});
    google.charts.setOnLoadCallback(grafica);
    
    function grafica() {
      // Crea la gráfica
      var data = new google.visualization.DataTable();
      data.addColumn('string', 'anio'); 
      data.addColumn('number', 'Chrome'); 
      data.addColumn('number', 'IE-Edge');
      data.addColumn('number', 'Firefox');
      data.addColumn('number', 'Safari');
      data.addColumn('number', 'Opera');
      data.addRows([
      <?php
          $i = 0;
          $n = mysqli_num_rows($r);
          while($row=mysqli_fetch_assoc($r)){
            print "['".$row["anio"]."', ".$row["Chrome"].", ".$row["IE-Edge"].", ".$row["Firefox"].", ".$row["Safari"].", ".$row["Opera"]."]";
            $i++;
            if($i<$n) print ",";
          }
        ?>
      ]);
      var opciones = {
        title: 'Participación de navegadores de 2008 a 2017',
        isStacked: "relative",
        fontSize:25,
        fontName:"Arial",
        colors:["red", "blue", "green", "violet", "orange"],
        hAxis: {
          title: 'Años',
          titleTextStyle: {color: 'orange', fontSize:30},
          textPosition: "out",
          textStyle: {color:"red", fontSize:20, fontName:"Times",bold:true, italic: true},
          slantedText: true,
          slantedTextAngle:60
        },
        vAxis: {
          title: 'Porcentajes',
          titleTextStyle: {color: '#FF0000', bold:true, fontSize:20, fontName: "Arial"},
          textStyle: {color: '#FF0000', bold:true, fontSize:20, fontName: "Arial"},
          gridlines: {color: 'gray', count: 4},
          format: "percent"
        },
        height:800
      };

      var grafica_div = document.getElementById('grafica_div');
      var chart = new google.visualization.AreaChart(grafica_div);

      // Espera a que termine de dibujarse  
      google.visualization.events.addListener(chart, 'ready', function () {
        //y llama la función getImageURI()
        grafica_div.innerHTML = '<img src="' + chart.getImageURI() + '">';
      });
      //Mandamos a dibujar la gráfico
      chart.draw(data, opciones);
  }
  </script>
</head>
<body>
  <h2 style="text-align: center; padding-top: 1em;">Data PNG</h2>
<div id='grafica_div'></div>
</body>
</html>