<?php
  $host = "localhost";
  $usuario = "root";
  $clave = "";
  $db = "escuela";
  //
  $conn = mysqli_connect($host, $usuario, $clave, $db) or die("Error");
  //
  $sql = "SELECT * FROM arbolPalabras";
  //
  $r = mysqli_query($conn, $sql);
?>
<html>
  <head>
    <script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>
    <script type="text/javascript">
      google.charts.load('current', {packages:['wordtree']});
      google.charts.setOnLoadCallback(grafica);

      function grafica() {
        var data = google.visualization.arrayToDataTable(
          [ ['frases'],
           <?php
            $i = 0;
            $n = mysqli_num_rows($r);
            while($row=mysqli_fetch_assoc($r)){
              $cadena = "['".utf8_decode($row["frase"])."']";
              $i++;
              if($i<$n) $cadena .= ",";
              print $cadena;
            }
          ?>
        ]);

        var opciones = {
          wordtree: {
            format: 'implicit',
            maxFontSize: 16,
            word: 'Juárez'
          }
        };

        var chart = new google.visualization.WordTree(document.getElementById('grafica'));
        chart.draw(data, opciones);
      }
    </script>
  </head>
  <body>
    <div id="grafica" style="width: 900px; height: 500px;"></div>
  </body>
</html>