-- phpMyAdmin SQL Dump
-- version 4.7.0
-- https://www.phpmyadmin.net/
--
-- Servidor: localhost:3306
-- Tiempo de generación: 19-08-2018 a las 17:54:21
-- Versión del servidor: 5.6.34-log
-- Versión de PHP: 7.1.5

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `escuela`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `arbolpalabras`
--

CREATE TABLE `arbolpalabras` (
  `id` int(11) NOT NULL,
  `frase` varchar(200) COLLATE latin1_spanish_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_spanish_ci;

--
-- Volcado de datos para la tabla `arbolpalabras`
--

INSERT INTO `arbolpalabras` (`id`, `frase`) VALUES
(2, 'JuÃ¡rez naciÃ³ en Guelatao, Oaxaca'),
(3, 'JuÃ¡rez estudiÃ³ leyes con los Jesuitas'),
(4, 'JuÃ¡rez participÃ³ en la revoluciÃ³n de Ayutla'),
(5, 'JuÃ¡rez participÃ³ en ConstituciÃ³n de 1857'),
(6, 'JuÃ¡rez fue gobernador de Oaxaca'),
(7, 'JuÃ¡rez fue presidente de MÃ©xico'),
(8, 'JuÃ¡rez combatiÃ³ a los Franceses'),
(9, 'JuÃ¡rez implantÃ³ las leyes de Reforma'),
(10, 'JuÃ¡rez muriÃ³ de angina de pecho');

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `arbolpalabras`
--
ALTER TABLE `arbolpalabras`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `arbolpalabras`
--
ALTER TABLE `arbolpalabras`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
