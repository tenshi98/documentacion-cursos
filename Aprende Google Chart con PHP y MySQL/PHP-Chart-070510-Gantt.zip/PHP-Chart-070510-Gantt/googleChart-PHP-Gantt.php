<?php
  $host = "localhost";
  $usuario = "root";
  $clave = "";
  $db = "escuela";
  //
  $conn = mysqli_connect($host, $usuario, $clave, $db) or die("Error");
  //
  $sql = "SELECT id, tarea, recursos, YEAR(inicio) as anio1, MONTH(inicio) as mes1, DAY(inicio) as dia1, YEAR(final) as anio2, MONTH(final) as mes2, DAY(final) as dia2, duracion, avance, dependencias FROM gantt";
  //
  $r = mysqli_query($conn, $sql);
  //
  $i = 0;
  $n = mysqli_num_rows($r);
  $datos = array();
  while($row=mysqli_fetch_assoc($r)){
    $dia1 = $row["dia1"];
    $mes1 = $row["mes1"];
    $anio1 = $row["anio1"];
    if($anio1!="0") {
      $inicio = "new Date(".$anio1.",".($mes1-1).",".$dia1.")";
    } else {
      $inicio = "null";
    }
    //
    $dia2 = $row["dia2"];
    $mes2 = $row["mes2"];
    $anio2 = $row["anio2"];
    if($anio2!="0") {
      $final = "new Date(".$anio2.",".($mes2-1).",".$dia2.")";
    } else {
      $final = "null";
    }
    if($row["dependencias"]=="") {
      $dependencias = "null";
    } else {
      $dependencias = $row["dependencias"];
    }
    //
    if($row["duracion"]==0){
      $duracion = "null";
    } else {
      $duracion = $row["duracion"] * 24 * 60 * 60 * 1000;
    }
    //
    $cadena = "['".$row["id"]."', '";
    $cadena .= $row["tarea"]."', ";
    $cadena .= $inicio.", ".$final.", ";
    $cadena .= $duracion.", ";
    $cadena .= $row["avance"].",";
    if($dependencias=="null"){
      $cadena .= $dependencias."]";
    } else {
      $cadena .= "'".$dependencias."']";
    }
    
    $i++;
    if($i<$n) $cadena .= ",";
    //print $cadena."<br>";
    array_push($datos,$cadena);
  }
?>
<html>
  <head>
    <!--Cargar AJAX API-->
    <script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>
    <script type="text/javascript">

      // Carga el API de visualización y el paquete corechart
      google.charts.load('current', {'packages':['gantt']});

      // Define la función callback para crear la gráfica
      google.charts.setOnLoadCallback(grafica);

      // Función para poblar la gráfica
      // iniciar el gráfico, pasa los datos y los dibuja
      function grafica() {

        // Crea la gráfica
        var data = new google.visualization.DataTable();
        data.addColumn('string', 'id');
        data.addColumn('string', 'tarea');
        data.addColumn('date', 'inicio');
        data.addColumn('date', 'fin');
        data.addColumn('number', 'duracion');
        data.addColumn('number', 'porcentaje');
        data.addColumn('string', 'dependencias');
        data.addRows([
          <?php
           for ($i = 0; $i < count($datos); $i++) {
             print $datos[$i];
           }
          ?>
        ]);

        // Opciones de la gráfica
        var opciones = {
          title:'Pasos para escribir una tesis',
          width:500,
          height:400,
          gantt: {
            criticalPathEnabled: false,
            innerGridHorizLine: {
              stroke: '#ffe0b2',
              strokeWidth: 2
            },
            innerGridTrack: {fill: '#fff3e0'},
            innerGridDarkTrack: {fill: '#ffcc80'}
          }
        };

        // Inicia la gráfica
        var chart = new google.visualization.Gantt(document.getElementById('grafica'));
        chart.draw(data, opciones);
      }
    </script>
  </head>

  <body>
    <!--División para la grafica-->
    <div id="grafica"></div>
  </body>
</html>