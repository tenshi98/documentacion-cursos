-- phpMyAdmin SQL Dump
-- version 4.7.0
-- https://www.phpmyadmin.net/
--
-- Servidor: localhost:3306
-- Tiempo de generación: 19-08-2018 a las 17:40:47
-- Versión del servidor: 5.6.34-log
-- Versión de PHP: 7.1.5

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `escuela`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `gantt`
--

CREATE TABLE `gantt` (
  `id` int(11) NOT NULL,
  `tarea` varchar(100) COLLATE latin1_spanish_ci DEFAULT NULL,
  `recursos` varchar(100) COLLATE latin1_spanish_ci DEFAULT NULL,
  `inicio` date NOT NULL,
  `final` date NOT NULL,
  `duracion` int(11) NOT NULL,
  `avance` int(11) NOT NULL,
  `dependencias` varchar(100) COLLATE latin1_spanish_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_spanish_ci;

--
-- Volcado de datos para la tabla `gantt`
--

INSERT INTO `gantt` (`id`, `tarea`, `recursos`, `inicio`, `final`, `duracion`, `avance`, `dependencias`) VALUES
(1, 'Recopilar bibliografia y fuentes', 'Libros e Internet', '2017-06-01', '2017-06-05', 0, 100, ''),
(2, 'Resumenes de los documentos', 'Libros e Internet', '0000-00-00', '2017-06-09', 3, 20, '1'),
(3, 'Crear bibliogarfia', 'Libros e Internet', '0000-00-00', '2017-06-11', 2, 30, '2'),
(4, 'Crear un indice tematico', 'Resumenes', '0000-00-00', '2017-06-15', 3, 20, '3'),
(5, 'Marco historico y teorico', 'Resumenes', '0000-00-00', '2017-06-21', 3, 0, '2,4'),
(6, 'Creacion de ejercicios', 'Resumenes', '0000-00-00', '2017-06-23', 2, 0, '5'),
(7, 'Primer borrador', 'Resumenes', '0000-00-00', '2017-06-30', 5, 0, '6');

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `gantt`
--
ALTER TABLE `gantt`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `gantt`
--
ALTER TABLE `gantt`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
