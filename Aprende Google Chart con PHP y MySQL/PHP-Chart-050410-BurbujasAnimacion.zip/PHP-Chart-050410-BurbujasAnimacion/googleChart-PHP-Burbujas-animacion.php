<?php
  $host = "localhost";
  $usuario = "root";
  $clave = "";
  $db = "escuela";
  //
  $conn = mysqli_connect($host, $usuario, $clave, $db) or die("Error");
  //
  $sql = "SELECT * FROM burbujas";
  //
  $r = mysqli_query($conn, $sql);
?>
<html>
  <head>
    <script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>
    <script type="text/javascript">
    google.charts.load("current", {packages:['corechart']});
    google.charts.setOnLoadCallback(grafica);
    //
    function grafica() {
      var data = google.visualization.arrayToDataTable([
        ["pais","expectativa","fertilidad","region","poblacion"],
            <?php
              $i = 0;
              $n = mysqli_num_rows($r);
              while($row=mysqli_fetch_assoc($r)){
                print "['".$row["pais"]."', ".$row["expectativa"].", ".$row["fertilidad"].", '".$row["region"]."', ".$row["poblacion"]."]";
                $i++;
                if($i<$n) print ",";
              }
            ?>
        ]);
      //
      var opciones = {
        title: 'Relación entre fertilidad-Expectativa de vida-población',
        fontSize:25,
        fontName:"Times",
        hAxis: {
          title: 'Expectativa de vida',
          titleTextStyle: {color: 'blue', fontSize:30},
          textPosition: "out",
          textStyle: {color:"blue", fontSize:20, fontName:"Times",bold:true, italic: true}
        },
        vAxis: {
          title: 'Tasa de fertilidad',
          titleTextStyle: {color: '#0000FF', bold:true, fontSize:30, fontName: "Arial"},
          textStyle: {color: '#0000FF', bold:true, fontSize:20, fontName: "Arial"},
          gridlines: {color: 'gray'}
        },
        titleTextStyle: { 
          color: "gray",
          fontSize: 40,
          italic: true 
        },
        animation:{
          duration: 1500,
          easing: 'out',
          startup: true
        },
        backgroundColor: {
          fill: "#eee",
          stroke: "black",
          strokeWidth: 10
        },
        bubble: {
          opacity: 1,
          stroke: 'black',
          textStyle: {
            fontSize: 12,
            fontName: 'Times-Roman',
            color: 'white',
            auraColor: 'black',
            bold: true,
            italic: true
          }
        },
        height: 600
      };
      var chart = new google.visualization.BubbleChart(document.getElementById("grafica"));
      chart.draw(data, opciones);
  }
  </script>
  </head>
  <body>
    <h2 style="text-align: center; padding-top: 1em;">Burbujas: animación</h2>
    <div id="grafica" ></div>
  </body>
</html>