<?php
  $host = "localhost";
  $usuario = "root";
  $clave = "";
  $db = "escuela";
  //
  $conn = mysqli_connect($host, $usuario, $clave, $db) or die("Error");
  //
  $sql = "SELECT * FROM candlestick";
?>
<html>
  <head>
    <script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>
    <script type="text/javascript">
      google.charts.load("current", {packages:["corechart"]});
      google.charts.setOnLoadCallback(grafica);

   function grafica() {
       var data = google.visualization.arrayToDataTable([
        //
        <?php
          $r = mysqli_query($conn, $sql);
          $i = 0;
          $n = mysqli_num_rows($r);
          while($row=mysqli_fetch_assoc($r)){
            print "['".$row["dia"]."',".$row["minimo"].",".$row["apertura"].",".$row["cierre"].",".$row["maximo"]."]";
            $i++;
            if($i<$n) print ",";
          }
        ?>
      ], true);
      //
      var opciones = {
        title: "Futuros del oro 2017",
        height: 350,
        legend: "none",
        animation:{
          startup: true,
          duration: 1000,
          easing: 'out'
        }
      };
      //
      var chart = new google.visualization.CandlestickChart(document.getElementById('grafica'));
      chart.draw(data, opciones);
   }
    </script>
  </head>
  <body>
    <div id="grafica" style="width: 1200px;"></div>
  </body>
</html>