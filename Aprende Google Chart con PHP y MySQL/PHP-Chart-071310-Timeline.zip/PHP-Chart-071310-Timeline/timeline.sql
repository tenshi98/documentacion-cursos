-- phpMyAdmin SQL Dump
-- version 4.7.0
-- https://www.phpmyadmin.net/
--
-- Servidor: localhost:3306
-- Tiempo de generación: 19-08-2018 a las 17:45:39
-- Versión del servidor: 5.6.34-log
-- Versión de PHP: 7.1.5

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `escuela`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `timeline`
--

CREATE TABLE `timeline` (
  `id` int(11) NOT NULL,
  `presidente` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `inicio` date NOT NULL,
  `fin` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Volcado de datos para la tabla `timeline`
--

INSERT INTO `timeline` (`id`, `presidente`, `inicio`, `fin`) VALUES
(1, 'Francisco I. Madero', '1911-11-06', '1913-02-19'),
(2, 'Victoriano Huerta', '1913-02-19', '1914-07-15'),
(3, 'Fco. S. Carbajal', '1914-07-15', '1914-08-13'),
(4, 'Eulalio Gtz. Ortiz', '1914-11-01', '1915-01-15'),
(5, 'Roque Gzl. Garza', '1915-01-01', '1915-07-10'),
(6, 'Fco. Lagos Chazaro', '1915-07-10', '1915-10-15'),
(7, 'Venustino Carranza', '1917-05-01', '1920-05-21'),
(8, 'Adolfo de la Huerta', '1920-07-01', '1920-11-30'),
(9, 'Alvaro Obregon', '1920-12-01', '1924-11-30'),
(10, 'Plutarco Elias Calles', '1924-12-01', '1928-11-28');

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `timeline`
--
ALTER TABLE `timeline`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `timeline`
--
ALTER TABLE `timeline`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
