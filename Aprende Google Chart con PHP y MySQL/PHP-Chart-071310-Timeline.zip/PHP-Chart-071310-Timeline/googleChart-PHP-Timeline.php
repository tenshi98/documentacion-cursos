<?php
  $host = "localhost";
  $usuario = "root";
  $clave = "";
  $db = "escuela";
  //
  $conn = mysqli_connect($host, $usuario, $clave, $db) or die("Error");
  //
  $sql = "SELECT presidente, YEAR(inicio) as anio1, MONTH(inicio) as mes1, DAY(inicio) as dia1, YEAR(fin) as anio2, MONTH(fin) as mes2, DAY(fin) as dia2  FROM timeline";
  //
  $r = mysqli_query($conn, $sql);
?>
<html>
  <head>
  <meta charset="utf-8">
    <script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>
    <script type="text/javascript">
      google.charts.load('current', {'packages':['timeline']});
      google.charts.setOnLoadCallback(grafica);

      function grafica() {
        var dataTable = new google.visualization.DataTable();
        dataTable.addColumn({ type: 'string', id: 'Presidente' });
        dataTable.addColumn({ type: 'date', id: 'Inicio' });
        dataTable.addColumn({ type: 'date', id: 'Fin' });
        dataTable.addRows([
          <?php
            $i = 0;
            $n = mysqli_num_rows($r);
            while($row=mysqli_fetch_assoc($r)){
              $cadena = "['".$row["presidente"]."',";
              $cadena .= "new Date(".$row["anio1"].",".($row["mes1"]-1).",".$row["dia1"]."),";
              $cadena .= "new Date(".$row["anio2"].",".($row["mes2"]-1).",".$row["dia2"].")]";
              $i++;
              if($i<$n) $cadena .= ",";
              print $cadena;
            }
          ?>
        ]);

        var chart = new google.visualization.Timeline(document.getElementById('timeline'));
        chart.draw(dataTable);
      }
    </script>
  </head>
  <body>
    <div id="timeline" style="height: 580px;"></div>
  </body>
</html>