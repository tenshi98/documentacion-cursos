<?php
  $host = "localhost";
  $usuario = "root";
  $clave = "";
  $db = "escuela";
  //
  $conn = mysqli_connect($host, $usuario, $clave, $db) or die("Error");
  //
  $sql = "SELECT * FROM estudiantes";
  //
  $r = mysqli_query($conn, $sql);
?>
<html>
  <head>
    <script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>
    <script type="text/javascript">
      google.charts.load("current", {packages:["corechart"]});
      google.charts.setOnLoadCallback(grafica);

      function grafica() {
        var data = google.visualization.arrayToDataTable([
          ['Alumno', 'Calificación'],
          <?php
            $i = 0;
            $n = mysqli_num_rows($r);
            while($row=mysqli_fetch_assoc($r)){
              print "['".$row["nombres"]." ".$row["apellidos"]."', ".$row["cali"]."]";
              $i++;
              if($i<$n) print ",";
            }
          ?>
        ]);

        var opciones = {
          title: 'Calificaciones',
          vAxis: { ticks: [2,4,6,8,10] },
          legend: { position: 'none' }
        };

        var chart = new google.visualization.Histogram(document.getElementById('grafica'));
        chart.draw(data, opciones);
      }
    </script>
  </head>
  <body>
    <h2 style="text-align: center; padding-top: 1em;">Histogramas</h2>
    <div id="grafica" style="width: 900px; height: 500px;"></div>
  </body>
</html>