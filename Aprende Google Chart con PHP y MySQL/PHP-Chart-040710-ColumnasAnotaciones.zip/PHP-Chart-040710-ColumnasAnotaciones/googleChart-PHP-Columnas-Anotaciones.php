<?php
  $host = "localhost";
  $usuario = "root";
  $clave = "";
  $db = "escuela";
  //
  $conn = mysqli_connect($host, $usuario, $clave, $db) or die("Error");
  //
  $sql = "SELECT * FROM navegadoresEstilos ORDER BY porcien DESC";
  //
  $r = mysqli_query($conn, $sql);
?>
<html>
  <head>
    <script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>
    <script type="text/javascript">
    google.charts.load("current", {packages:['corechart']});
    google.charts.setOnLoadCallback(grafica);

    function grafica() {
      var data = google.visualization.arrayToDataTable([
        ["Navegador","Participación", { role: 'style' }, { role: 'annotation' }],
          <?php
            $i = 0;
            $n = mysqli_num_rows($r);
            while($row=mysqli_fetch_assoc($r)){
              print "['".$row["navegador"]."', ".$row["porcien"].", '".$row["estilo"]."', '".$row["porcien"]."']";
              $i++;
              if($i<$n) print ",";
            }
          ?>
        ]);
      //
      var opciones = {
        title: 'Participación de navegadores en 2017',
        fontSize:25,
        fontName:"Times",
        hAxis: {
          title: 'Navegadores',
          titleTextStyle: {color: 'blue', fontSize:30},
          textPosition: "out",
          textStyle: {color:"blue", fontSize:20, fontName:"Times",bold:true, italic: true}
        },
        vAxis: {
          title: 'Porcentaje de participación',
          titleTextStyle: {color: '#0000FF', bold:true, fontSize:30, fontName: "Arial"},
          textStyle: {color: '#0000FF', bold:true, fontSize:20, fontName: "Arial"},
          gridlines: {color: 'gray'}
        },
        legend: { position: 'none'},
        titleTextStyle: { 
          color: "gray",
          fontSize: 40,
          italic: true 
        },
        annotations: {
            textStyle: {
              fontName: 'Times-Roman',
              fontSize: 38,
              bold: true,
              italic: true,
              // Opacidad.
              opacity: 0.8
            }
          },
        bar:{groupWidth: "80%"},
        height: 600
      };
      var chart = new google.visualization.ColumnChart(document.getElementById("grafica"));
      chart.draw(data, opciones);
  }
  </script>
  </head>
  <body>
    <h2 style="text-align: center; padding-top: 1em;">Gráfica de barras: Anotaciones</h2>
    <div id="grafica" ></div>
  </body>
</html>