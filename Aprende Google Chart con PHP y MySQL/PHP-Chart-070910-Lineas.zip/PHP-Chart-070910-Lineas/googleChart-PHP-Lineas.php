<?php
  $host = "localhost";
  $usuario = "root";
  $clave = "";
  $db = "escuela";
  //
  $conn = mysqli_connect($host, $usuario, $clave, $db) or die("Error");
  //
  $sql = "SELECT * FROM historicoTabular ORDER BY anio";
  //
  $r = mysqli_query($conn, $sql);
?>
 <html>
  <head>
    <script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>
    <script type="text/javascript">
      google.charts.load('current', {'packages':['corechart']});
      google.charts.setOnLoadCallback(grafica);

      function grafica() {
        var data = google.visualization.arrayToDataTable([
          ["Año","Chrome","IE-Edge","Firefox","Safari","Opera"],
          <?php
            $i = 0;
            $n = mysqli_num_rows($r);
            while($row=mysqli_fetch_assoc($r)){
              print "['".$row["anio"]."', ".$row["Chrome"].", ".$row["IE-Edge"].", ".$row["Firefox"].", ".$row["Safari"].", ".$row["Opera"]."]";
              $i++;
              if($i<$n) print ",";
            }
          ?>
        ]);

        var opciones = {
          curveType: 'function',
          title: 'Participación de navegadores de 2008 a 2017',
          hAxis: {title: 'Años',  titleTextStyle: {color: '#333'}},
          vAxis: {title: 'Navegadores', titleTextStyle: {color: '#FF0000'}}
        };

        var chart = new google.visualization.LineChart(document.getElementById('grafica'));

        chart.draw(data, opciones);
      }
    </script>
  </head>
  <body>
    <h2 style="text-align: center; padding-top: 1em;">Líneas</h2>
    <div id="grafica" style="width: 900px; height: 500px"></div>
  </body>
</html>