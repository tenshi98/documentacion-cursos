<?php
  $host = "localhost";
  $usuario = "root";
  $clave = "";
  $db = "escuela";
  //
  $conn = mysqli_connect($host, $usuario, $clave, $db) or die("Error");
  //
  $sql = "SELECT DAY(fecha) as dia, MONTH(fecha) as mes, YEAR(fecha) as anio, medida FROM calendar";
?>
<html>
  <head>
    <script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>
    <script type="text/javascript">
      google.charts.load("current", {packages:["calendar"]});
      google.charts.setOnLoadCallback(grafica);

   function grafica() {
       var dataTable = new google.visualization.DataTable();
       dataTable.addColumn({ type: 'date', id: 'fecha' });
       dataTable.addColumn({ type: 'number', id: 'medida' });
       dataTable.addRows([
        //
        <?php
          $r = mysqli_query($conn, $sql);
          $i = 0;
          $n = mysqli_num_rows($r);
          while($row=mysqli_fetch_assoc($r)){
            print "[new Date(".$row["anio"].",".($row["mes"]-1).",".$row["dia"]."), ".$row["medida"]."]";
            $i++;
            if($i<$n) print ",";
          }
        ?>
      ]);
      //
      var opciones = {
        title: "Medidas de glucosa",
        height: 350,
        calendar: {
          cellSize: 20,
          cellColor: {
            stroke: '#76a7fa',
            strokeOpacity: 0.2,
            strokeWidth: 1,
          },
          focusedCellColor: {
            stroke: 'red',
            strokeOpacity: 1,
            strokeWidth: 1,
          }
        },
        noDataPattern: {
           backgroundColor: 'orange',
           color: 'yellow'
        }
      };
      //
      var chart = new google.visualization.Calendar(document.getElementById('grafica'));
      chart.draw(dataTable, opciones);
   }
    </script>
  </head>
  <body>
    <div id="grafica" style="width: 1200px;"></div>
  </body>
</html>