<?php
  $host = "localhost";
  $usuario = "root";
  $clave = "";
  $db = "escuela";
  //
  $conn = mysqli_connect($host, $usuario, $clave, $db) or die("Error");
  //
  $sql = "SELECT * FROM correlacion";
  //
  $r = mysqli_query($conn, $sql);
?>
<html>
  <head>
    <script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>
    <script type="text/javascript">
      google.charts.load('current', {'packages':['corechart']});
      google.charts.setOnLoadCallback(drawChart);

      function drawChart() {
        var data = google.visualization.arrayToDataTable([
          ['Edad', 'Peso'],
          <?php
            $i = 0;
            $n = mysqli_num_rows($r);
            while($row=mysqli_fetch_assoc($r)){
              $cadena = "[".$row["edad"].",".$row["peso"]."]";
              $i++;
              if($i<$n) $cadena .= ",";
              print $cadena;
            }
          ?>
        ]);

        var opciones = {
          title: 'Correlación entre edad vs. peso',
          hAxis: {title: 'Edad', minValue: 0, maxValue: 15},
          vAxis: {title: 'Peso', minValue: 0, maxValue: 15},
          trendlines: { 0: {} },
          legend: 'none'
        };

        var chart = new google.visualization.ScatterChart(document.getElementById('grafica'));
        chart.draw(data, opciones);
      }
    </script>
  </head>
  <body>
    <h2 style="text-align: center; padding-top: 1em;">Correlació lineal</h2>
    <div id="grafica" style="width: 900px; height: 500px;"></div>
  </body>
</html>