<?php
  $host = "localhost";
  $usuario = "root";
  $clave = "";
  $db = "escuela";
  //
  $conn = mysqli_connect($host, $usuario, $clave, $db) or die("Error");
  //
  $sql = "SELECT * FROM Mapas";
  //
  $r = mysqli_query($conn, $sql);
?>
<html>
  <head>
  <meta charset="utf-8">
  <script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>
  <title>GooglrChart - Mapa</title>
  <script>
    google.charts.load('current', {
        'packages':['map'],
        //https://developers.google.com/chart/interactive/docs/basic_load_libs#load-settings
        'mapsApiKey': 'AIzaSyD-9tSrke72PouQMnMX-a7eZSW0jkFMBWY'
      });
    google.charts.setOnLoadCallback(grafica);

    function grafica() {
      var data = google.visualization.arrayToDataTable([
        ['País', 'Población'],
          <?php
            $i = 0;
            $n = mysqli_num_rows($r);
            while($row=mysqli_fetch_assoc($r)){
              //
              $cadena = "['".$row["pais"]."',";
              $cadena .= "'".$row["poblacion"]."']";
              $i++;
              if($i<$n) $cadena .= ",";
              //print $cadena."<br>";
              print $cadena;
            }
          ?>
      ]);

    var opciones = {
      showTooltip: true,
      showInfoWindow: true
    };

    var map = new google.visualization.Map(document.getElementById('mapa'));

    map.draw(data, opciones);
  };
  </script>
  </head>
  <body>
    <div id="mapa"></div>
  </body>
</html>