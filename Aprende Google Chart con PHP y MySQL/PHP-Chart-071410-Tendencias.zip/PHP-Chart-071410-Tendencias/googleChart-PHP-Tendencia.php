<?php
  $host = "localhost";
  $usuario = "root";
  $clave = "";
  $db = "escuela";
  $t = 2;
  $tipo = ["linear","exponential","polynomial"];
  $max1 = [15,3,12];
  $max2 = [15,2100,16];
  //
  $conn = mysqli_connect($host, $usuario, $clave, $db) or die("Error");
  //
  $sql = "SELECT * FROM tendencias WHERE tipo='".$tipo[$t]."'";
  //
  $r = mysqli_query($conn, $sql);
?>
<html>
  <head>
    <script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>
    <script type="text/javascript">
      google.charts.load('current', {'packages':['corechart']});
      google.charts.setOnLoadCallback(grafica);

      function grafica() {
        var data = google.visualization.arrayToDataTable([
          ['Variable1', 'Variable2'],
          <?php
            $i = 0;
            $n = mysqli_num_rows($r);
            while($row=mysqli_fetch_assoc($r)){
              $cadena = "[".$row["variable1"].",".$row["variable2"]."]";
              $i++;
              if($i<$n) $cadena .= ",";
              print $cadena;
            }
          ?>
        ]);

        var opciones = {
          title: 'Correlación entre variable1 vs. variable 2',
          hAxis: {title: 'Variable 1', minValue: 0, maxValue: <?php print $max1[$t]; ?>},
          vAxis: {title: 'Variable 2', minValue: 0, maxValue: <?php print $max2[$t]; ?>},
          trendlines: {
             0: {
                 type: '<?php print $tipo[$t]; ?>',
                 visibleInLegend: true,
              }
          },
          legend: 'none'
        };

        var chart = new google.visualization.ScatterChart(document.getElementById('grafica'));
        chart.draw(data, opciones);
      }
    </script>
  </head>
  <body>
    <div id="grafica" style="width: 900px; height: 500px;"></div>
  </body>
</html>