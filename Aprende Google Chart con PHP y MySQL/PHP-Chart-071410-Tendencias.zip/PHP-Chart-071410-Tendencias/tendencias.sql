-- phpMyAdmin SQL Dump
-- version 4.7.0
-- https://www.phpmyadmin.net/
--
-- Servidor: localhost:3306
-- Tiempo de generación: 19-08-2018 a las 17:45:17
-- Versión del servidor: 5.6.34-log
-- Versión de PHP: 7.1.5

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `escuela`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `tendencias`
--

CREATE TABLE `tendencias` (
  `id` int(11) NOT NULL,
  `tipo` varchar(20) COLLATE latin1_spanish_ci NOT NULL,
  `variable1` int(11) NOT NULL,
  `variable2` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_spanish_ci;

--
-- Volcado de datos para la tabla `tendencias`
--

INSERT INTO `tendencias` (`id`, `tipo`, `variable1`, `variable2`) VALUES
(1, 'linear', 8, 37),
(2, 'linear', 4, 19),
(3, 'linear', 11, 52),
(4, 'linear', 4, 22),
(5, 'linear', 3, 16),
(6, 'linear', 7, 33),
(7, 'linear', 14, 72),
(8, 'exponential', 0, 1),
(9, 'exponential', 1, 33),
(10, 'exponential', 2, 269),
(11, 'exponential', 3, 2013),
(12, 'polynomial', 8, 12),
(13, 'polynomial', 4, 6),
(14, 'polynomial', 11, 14),
(15, 'polynomial', 4, 5),
(16, 'polynomial', 3, 4),
(17, 'polynomial', 7, 7);

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `tendencias`
--
ALTER TABLE `tendencias`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `tendencias`
--
ALTER TABLE `tendencias`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
