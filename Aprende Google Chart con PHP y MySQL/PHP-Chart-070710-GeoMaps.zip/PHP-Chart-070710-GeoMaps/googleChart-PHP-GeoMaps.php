<?php
  $host = "localhost";
  $usuario = "root";
  $clave = "";
  $db = "escuela";
  //
  $conn = mysqli_connect($host, $usuario, $clave, $db) or die("Error");
  //
  $sql = "SELECT * FROM GeoChart";
  //
  $r = mysqli_query($conn, $sql);
?>
<html>
  <head>
    <script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>
    <script type="text/javascript">
      google.charts.load('current', {
        'packages':['geochart'],
        //https://developers.google.com/chart/interactive/docs/basic_load_libs#load-settings
        'mapsApiKey': 'AIzaSyD-9tSrke72PouQMnMX-a7eZSW0jkFMBWY'
      });
      google.charts.setOnLoadCallback(grafica);

      function grafica() {
        var data = google.visualization.arrayToDataTable([
          ['País', 'Población'],
          <?php
            $i = 0;
            $n = mysqli_num_rows($r);
            while($row=mysqli_fetch_assoc($r)){
              //
              $cadena = "['".$row["pais"]."',";
              $cadena .= "".$row["poblacion"]."]";
              $i++;
              if($i<$n) $cadena .= ",";
              //print $cadena."<br>";
              print $cadena;
            }
          ?>
        ]);

        var opciones = {
          region: "005"
        };

        var chart = new google.visualization.GeoChart(document.getElementById('mapa'));

        chart.draw(data, opciones);
      }
    </script>
  </head>
  <body>
    <h2 style="text-align: center; padding-top: 1em;">Mapas</h2>
    <div id="mapa" style="width: 900px; height: 500px;"></div>
  </body>
</html>