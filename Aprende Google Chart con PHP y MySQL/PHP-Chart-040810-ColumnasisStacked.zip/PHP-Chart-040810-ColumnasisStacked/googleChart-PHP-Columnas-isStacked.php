<?php
  $host = "localhost";
  $usuario = "root";
  $clave = "";
  $db = "escuela";
  //
  $conn = mysqli_connect($host, $usuario, $clave, $db) or die("Error");
  //
  $sql = "SELECT * FROM historicoTabular ORDER BY anio";
  //
  $r = mysqli_query($conn, $sql);
?>
<html>
  <head>
    <script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>
    <script type="text/javascript">
    google.charts.load("current", {packages:['corechart']});
    google.charts.setOnLoadCallback(drawChart);
    function drawChart() {
      var data = google.visualization.arrayToDataTable([
        ["Año","Chrome","IE-Edge","Firefox","Safari","Opera"],
            <?php
              $i = 0;
              $n = mysqli_num_rows($r);
              while($row=mysqli_fetch_assoc($r)){
                print "['".$row["anio"]."', ".$row["Chrome"].", ".$row["IE-Edge"].", ".$row["Firefox"].", ".$row["Safari"].", ".$row["Opera"]."]";
                $i++;
                if($i<$n) print ",";
              }
            ?>
        ]);
      //
      var opciones = {
        title: 'Participación de navegadores de 2008 a 2017',
        fontSize:25,
        fontName:"Times",
        hAxis: {
          title: 'Navegadores',
          titleTextStyle: {color: 'blue', fontSize:30},
          textPosition: "out",
          textStyle: {color:"blue", fontSize:20, fontName:"Times",bold:true, italic: true}
        },
        vAxis: {
          title: 'Porcentaje de participación',
          titleTextStyle: {color: '#0000FF', bold:true, fontSize:30, fontName: "Arial"},
          textStyle: {color: '#0000FF', bold:true, fontSize:20, fontName: "Arial"},
          gridlines: {color: 'gray'}
        },
        titleTextStyle: { 
          color: "gray",
          fontSize: 40,
          italic: true 
        },
        bar:{groupWidth: "80%"},
        isStacked: true,
        height: 600
      };
      var chart = new google.visualization.ColumnChart(document.getElementById("grafica"));
      chart.draw(data, opciones);
  }
  </script>
  </head>
  <body>
    <h2 style="text-align: center; padding-top: 1em;">Gráfica de barras</h2>
    <div id="grafica" ></div>
  </body>
</html>