<?php
  $host = "localhost";
  $usuario = "root";
  $clave = "";
  $db = "escuela";
  //
  $conn = mysqli_connect($host, $usuario, $clave, $db) or die("Error");
  //
  $sql = "SELECT * FROM historicoTabular ORDER BY anio DESC LIMIT 4";
  //
  $r = mysqli_query($conn, $sql);
?>
<html>
  <head>
    <script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>
    <script type="text/javascript">
      google.charts.load('current', {'packages':['bar']});
      google.charts.setOnLoadCallback(grafica);

      function grafica() {
         // Crea la gráfica
        var data = google.visualization.arrayToDataTable([
          ["Año","Chrome","IE-Edge","Firefox","Safari","Opera"],
            <?php
              $i = 0;
              $n = mysqli_num_rows($r);
              while($row=mysqli_fetch_assoc($r)){
                print "['".$row["anio"]."', ".$row["Chrome"].", ".$row["IE-Edge"].", ".$row["Firefox"].", ".$row["Safari"].", ".$row["Opera"]."]";
                $i++;
                if($i<$n) print ",";
              }
            ?>
        ]);
        var opciones = {
          chart: {
            title: 'Participación por navegador',
            subtitle: '2014-2017'
          },
          //isStacked: true,
          bars: 'horizontal',
          fontSize:25,
          fontName:"Times",
          hAxis: {
            title: 'Porcenjate de participación',
            titleTextStyle: {color: 'blue', fontSize:30},
            textPosition: "out",
            textStyle: {color:"blue", fontSize:20, fontName:"Times",bold:true, italic: true}
          },
          vAxis: {
            title: 'Navegadores',
            titleTextStyle: {color: '#0000FF', bold:true, fontSize:30, fontName: "Arial"},
            textStyle: {color: '#0000FF', bold:true, fontSize:20, fontName: "Arial"},
            gridlines: {color: 'gray'}
          },
          colors: ["red","green","yellow","blue","orange"],
          titleTextStyle: { 
            color: "gray",
            fontSize: 40,
            italic: true 
          },
          isStacked: true,
          height: 900
        };

        var chart = new google.charts.Bar(document.getElementById('grafica'));
        chart.draw(data, google.charts.Bar.convertOptions(opciones));
      }
    </script>
  </head>
  <body>
    <h2 style="text-align: center; padding-top: 1em;">Barras: isStacked</h2>
    <div id="grafica" ></div>
  </body>
</html>