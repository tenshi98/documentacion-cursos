<?php
  $host = "localhost";
  $usuario = "root";
  $clave = "";
  $db = "escuela";
  //
  $conn = mysqli_connect($host, $usuario, $clave, $db) or die("Error");
  //
  $sql = "SELECT * FROM indicadores";
  //
  $r = mysqli_query($conn, $sql);
  $row = mysqli_fetch_assoc($r);
?>
<html>
  <head>
  <style>
    div{float:left;}
  </style>
   <script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>
   <script type="text/javascript">
      google.charts.load('current', {'packages':['gauge']});
      google.charts.setOnLoadCallback(azucar);
      google.charts.setOnLoadCallback(colesterol);
      google.charts.setOnLoadCallback(trigliceridos);

      function azucar() {
        var data = google.visualization.arrayToDataTable([
          ['Etiqueta', 'Valor'],
          <?php
            print "['Azucar',".$row["azucar"]."]";
          ?>
        ]);
        var options = {
          width: 400, height: 120,
          redFrom: 140, redTo: 300,
          greenFrom:70, greenTo: 120,
          yellowFrom:121, yellowTo: 140,
          min:70,
          max:300,
          minorTicks: 5
        };
        var chart = new google.visualization.Gauge(document.getElementById('azucar'));
        chart.draw(data, options);
      }

      function colesterol() {
        var data = google.visualization.arrayToDataTable([
          ['Etiqueta', 'Valor'],
          <?php
            print "['Colesterol',".$row["colesterol"]."]";
          ?>
        ]);
        var options = {
          width: 400, height: 120,
          greenFrom:0, greenTo: 200,
          yellowFrom:201, yellowTo: 220,
          redFrom: 221, redTo: 400,
          min:0,
          max:400,
          minorTicks: 5
        };
        var chart = new google.visualization.Gauge(document.getElementById('colesterol'));
        chart.draw(data, options);
      }

      function trigliceridos() {
        var data = google.visualization.arrayToDataTable([
          ['Etiqueta', 'Valor'],
          <?php
            print "['Trigliceridos',".$row["trigliceridos"]."]";
          ?>
        ]);
        var options = {
          width: 400, height: 120,
          greenFrom:0, greenTo: 150,
          yellowFrom:151, yellowTo: 170,
          redFrom: 171, redTo: 200,
          min:0,
          max:200,
          minorTicks: 5,
        };
        var chart = new google.visualization.Gauge(document.getElementById('trigliceridos'));
        chart.draw(data, options);
      }
    </script>
  </head>
  <body>
    <h2 style="text-align: center; padding-top: 1em;">Indicadores</h2>
    <div id="azucar" style="width: 180px; height: 120px;"></div>
    <div id="colesterol" style="width: 180px; height: 120px;"></div>
    <div id="trigliceridos" style="width: 180px; height: 120px;"></div>
  </body>
</html>