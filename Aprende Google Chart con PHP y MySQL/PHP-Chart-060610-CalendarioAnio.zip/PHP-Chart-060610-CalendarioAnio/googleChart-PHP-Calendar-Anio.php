<?php
  $host = "localhost";
  $usuario = "root";
  $clave = "";
  $db = "escuela";
  //
  $conn = mysqli_connect($host, $usuario, $clave, $db) or die("Error");
  //
  $sql = "SELECT DAY(fecha) as dia, MONTH(fecha) as mes, YEAR(fecha) as anio, medida FROM calendar";
?>
<html>
  <head>
    <script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>
    <script type="text/javascript">
      google.charts.load("current", {packages:["calendar"]});
      google.charts.setOnLoadCallback(grafica);

   function grafica() {
       var dataTable = new google.visualization.DataTable();
       dataTable.addColumn({ type: 'date', id: 'fecha' });
       dataTable.addColumn({ type: 'number', id: 'medida' });
       dataTable.addRows([
        //
        <?php
          $r = mysqli_query($conn, $sql);
          $i = 0;
          $n = mysqli_num_rows($r);
          while($row=mysqli_fetch_assoc($r)){
            print "[new Date(".$row["anio"].",".($row["mes"]-1).",".$row["dia"]."), ".$row["medida"]."]";
            $i++;
            if($i<$n) print ",";
          }
        ?>
      ]);
      //
      var opciones = {
        title: "Medidas de glucosa",
        height: 350,
        calendar: {
          cellSize: 20,
          cellColor: {
            stroke: '#76a7fa',
            strokeOpacity: 0.2,
            strokeWidth: 1,
          },
          focusedCellColor: {
            stroke: 'red',
            strokeOpacity: 1,
            strokeWidth: 1,
          },
          dayOfWeekLabel: {
            fontName: 'Times-Roman',
            fontSize: 12,
            color: '#1a8763',
            bold: true,
            italic: true,
          },
          dayOfWeekRightSpace: 15,
          daysOfWeek: 'DLMMJVS',
          monthLabel: {
            fontName: 'Times-Roman',
            fontSize: 12,
            color: 'red',
            bold: true,
            italic: true
          },
          monthOutlineColor: {
            stroke: '#981b48',
            strokeOpacity: 0.8,
            strokeWidth: 2
          },
          unusedMonthOutlineColor: {
            stroke: '#bc5679',
            strokeOpacity: 0.8,
            strokeWidth: 1
          },
          underMonthSpace: 16,
          //
          underYearSpace: 20,
          yearLabel: {
            fontName: 'Times-Roman',
            fontSize: 50,
            color: '#1A8763',
            bold: true,
            italic: true
          }
        },
        noDataPattern: {
           backgroundColor: 'orange',
           color: 'yellow'
        }
      };
      //
      var chart = new google.visualization.Calendar(document.getElementById('grafica'));
      chart.draw(dataTable, opciones);
   }
    </script>
  </head>
  <body>
    <div id="grafica" style="width: 1200px;"></div>
  </body>
</html>