-- phpMyAdmin SQL Dump
-- version 4.7.0
-- https://www.phpmyadmin.net/
--
-- Servidor: localhost:3306
-- Tiempo de generación: 19-08-2018 a las 17:39:49
-- Versión del servidor: 5.6.34-log
-- Versión de PHP: 7.1.5

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `escuela`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `escalonadas`
--

CREATE TABLE `escalonadas` (
  `id` int(11) NOT NULL,
  `pelicula` varchar(100) COLLATE latin1_spanish_ci NOT NULL,
  `usa_today` float NOT NULL,
  `ny_post` float NOT NULL,
  `w_post` float NOT NULL,
  `reforma` float NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_spanish_ci;

--
-- Volcado de datos para la tabla `escalonadas`
--

INSERT INTO `escalonadas` (`id`, `pelicula`, `usa_today`, `ny_post`, `w_post`, `reforma`) VALUES
(1, 'Cars 3', 2.5, 2.5, 2, 2),
(2, 'La momia', 2, 1, 2.5, 2.5),
(3, 'Bay Watch', 1, 1.5, 1, 1),
(4, 'Rapido y furioso', 2, 1.5, 1, 1.5),
(5, 'La tortuga roja', 3, 3.5, 3, 4);

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `escalonadas`
--
ALTER TABLE `escalonadas`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `escalonadas`
--
ALTER TABLE `escalonadas`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
