<?php
  $host = "localhost";
  $usuario = "root";
  $clave = "";
  $db = "escuela";
  //
  $conn = mysqli_connect($host, $usuario, $clave, $db) or die("Error");
  //
  $sql = "SELECT * FROM escalonadas";
  //
  $r = mysqli_query($conn, $sql);
?>
<html>
  <head>
    <script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>
    <script type="text/javascript">
      google.charts.load('current', {'packages':['corechart']});
      google.charts.setOnLoadCallback(grafica);

      function grafica() {
        var data = google.visualization.arrayToDataTable([
          ['Pelicula',  'USA Today', 'New York Post', 'Washington Post', 'Reforma'],
          <?php
            $i = 0;
            $n = mysqli_num_rows($r);
            while($row=mysqli_fetch_assoc($r)){
              $cadena = "['".$row["pelicula"]."',";
              $cadena .= $row["usa_today"].",";
              $cadena .= $row["ny_post"].",";
              $cadena .= $row["w_post"].",";
              $cadena .= $row["reforma"]."]";
              $i++;
              if($i<$n) $cadena .= ",";
              print $cadena;
            }
          ?>
        ]);

        var opciones = {
          title: 'Cartelera Junio 2017',
          vAxis: {title: 'Calificaciones acumuladas'},
          isStacked: true
        };

        var chart = new google.visualization.SteppedAreaChart(document.getElementById('grafica'));

        chart.draw(data, opciones);
      }
    </script>
  </head>
  <body>
    <h2 style="text-align: center; padding-top: 1em;">Gráfica escalonada</h2>
    <div id="grafica" style="width: 900px; height: 500px;"></div>
  </body>
</html>