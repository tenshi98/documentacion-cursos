-- phpMyAdmin SQL Dump
-- version 4.7.0
-- https://www.phpmyadmin.net/
--
-- Servidor: localhost:3306
-- Tiempo de generación: 19-08-2018 a las 17:56:33
-- Versión del servidor: 5.6.34-log
-- Versión de PHP: 7.1.5

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `escuela`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `burbujas`
--

CREATE TABLE `burbujas` (
  `id` int(11) NOT NULL,
  `pais` varchar(10) COLLATE latin1_spanish_ci NOT NULL,
  `expectativa` int(11) NOT NULL,
  `fertilidad` int(11) NOT NULL,
  `region` varchar(20) COLLATE latin1_spanish_ci NOT NULL,
  `poblacion` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_spanish_ci;

--
-- Volcado de datos para la tabla `burbujas`
--

INSERT INTO `burbujas` (`id`, `pais`, `expectativa`, `fertilidad`, `region`, `poblacion`) VALUES
(1, 'CAN', 81, 2, 'America', 33739900),
(2, 'ALE', 80, 1, 'Europa', 81902307),
(3, 'DNK', 79, 2, 'Europa', 5523095),
(4, 'EGY', 73, 3, 'Oriente Medio', 79716203),
(5, 'GBR', 80, 2, 'Europa', 61801570),
(6, 'IRN', 72, 2, 'Oriente Medio', 73137148),
(7, 'IRQ', 68, 5, 'Oriente Medio', 31090763),
(8, 'ISR', 82, 3, 'Oriente Medio', 7485600),
(9, 'RUS', 69, 2, 'Europa', 141850000),
(10, 'USA', 78, 2, 'America', 307007000),
(11, 'MX', 77, 2, 'America', 127000000),
(12, 'ARG', 76, 2, 'America', 43000000);

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `burbujas`
--
ALTER TABLE `burbujas`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `burbujas`
--
ALTER TABLE `burbujas`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
