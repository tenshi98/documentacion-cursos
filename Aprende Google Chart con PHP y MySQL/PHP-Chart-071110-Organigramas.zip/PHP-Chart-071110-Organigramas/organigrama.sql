-- phpMyAdmin SQL Dump
-- version 4.7.0
-- https://www.phpmyadmin.net/
--
-- Servidor: localhost:3306
-- Tiempo de generación: 19-08-2018 a las 17:44:58
-- Versión del servidor: 5.6.34-log
-- Versión de PHP: 7.1.5

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `escuela`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `organigrama`
--

CREATE TABLE `organigrama` (
  `id` int(11) NOT NULL,
  `valor` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `formato` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `dependencia` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `tooltip` varchar(100) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Volcado de datos para la tabla `organigrama`
--

INSERT INTO `organigrama` (`id`, `valor`, `formato`, `dependencia`, `tooltip`) VALUES
(1, 'direccion', 'Direcci&oacute;n<div style=\"color:red; font-style:italic\">Lic. Gonz&aacute;lez</div>', '', 'Lic. Jorge Gonzalez'),
(2, 'mercadotecnia', 'Mercadotecnia<div style=\"color:blue; font-style:italic\">Lic. Lopez</div>', 'direccion', 'Lic. Martha Rico'),
(3, 'finanzas', 'Finanzas<div style=\"color:blue; font-style:italic\">Lic. Estrada</div>', 'direccion', 'Lic. Ricardo Estrada'),
(4, 'rrhh', 'Recursos Humanos<div style=\"color:blue; font-style:italic\">Lic. Alvarado</div>', 'direccion', 'Lic. Michell Alvarado'),
(5, 'produccion', 'Producci&oacute;n<div style=\"color:blue; font-style:italic\">Lic. Hern&aacute;ndez</div>', 'direccion', 'Ing. Eduardo Hernandez'),
(6, 'ventas', 'Ventas<div style=\"color:red; font-style:italic\">(vacante)</div>', 'mercadotecnia', '(vacante)'),
(7, 'publicidad', 'Publicidad<div style=\"color:red; font-style:italic\">D.G. Culqui</div>', 'mercadotecnia', 'D.G. Clara Culqui'),
(8, 'capacitacion', 'Capacitaci&oacute;n<div style=\"color:red; font-style:italic\">Mta. Arce</div>', 'rrhh', 'Mta. Laura Arce'),
(9, 'compras', 'Compras<div style=\"color:red; font-style:italic\">Ing. S&aacute;nchez</div>', 'produccion', 'Ing. Jose Sanchez'),
(10, 'fabrica', 'F&aacute;brica<div style=\"color:green; font-style:italic\">Ing. Salbuchi</div>', 'produccion', 'Ing. Antonio Salbuchi');

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `organigrama`
--
ALTER TABLE `organigrama`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `organigrama`
--
ALTER TABLE `organigrama`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
