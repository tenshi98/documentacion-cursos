<?php
  $host = "localhost";
  $usuario = "root";
  $clave = "";
  $db = "escuela";
  //
  $conn = mysqli_connect($host, $usuario, $clave, $db) or die("Error");
  //
  $sql = "SELECT * FROM organigrama";
  //
  $r = mysqli_query($conn, $sql);
?>
<html>
  <head>
    <meta charset="utf-8">
    <script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>
    <script type="text/javascript">
      google.charts.load('current', {packages:["orgchart"]});
      google.charts.setOnLoadCallback(grafica);

      function grafica() {
        var data = new google.visualization.DataTable();
        data.addColumn('string', 'Nombre');
        data.addColumn('string', 'Dependencia');
        data.addColumn('string', 'ToolTip');

        data.addRows([
          <?php
            $i = 0;
            $n = mysqli_num_rows($r);
            while($row=mysqli_fetch_assoc($r)){
              $cadena = "[{v:'".$row["valor"]."', f:'".$row["formato"]."'},";
              $cadena .= "'".$row["dependencia"]."',";
              $cadena .= "'".$row["tooltip"]."']";
              $i++;
              if($i<$n) $cadena .= ",";
              print $cadena;
            }
          ?>
        ]);

        var opciones = {
          allowHtml:true
        }

        // Contruimos la gráfica
        var chart = new google.visualization.OrgChart(document.getElementById('grafica'));
        // Dibujamos la gráfica
        chart.draw(data, opciones );
      }
   </script>
    </head>
  <body>
    <div id="grafica"></div>
  </body>
</html>