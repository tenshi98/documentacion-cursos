<?php
  $host = "localhost";
  $usuario = "root";
  $clave = "root";
  $db = "escuela";
  //
  $conn = mysqli_connect($host, $usuario, $clave, $db) or die("Error");
  //
  $sql = "SELECT * FROM graficaJSON";
  //
  $r = mysqli_query($conn, $sql);
  $ii = 0;
  $n = mysqli_num_rows($r);
  $c = array();
  $t = array();
  while($row=mysqli_fetch_assoc($r)){
    array_push($c, $row);
  }
  //
  $cadena = '{"cols": [';
  for($i=0; $i<count($c); $i++){
    $id = $c[$i]["id"];
    $tipo = $c[$i]["tipo"];
    $indice = $c[$i]["indice"];
    if($tipo=="col"){
      if($indice!=$ii){
        $cadena .= "{";
        $ii = $indice;
      }
      if($c[$i]["prop"]=="type"){
        array_push($t, $c[$i]["valor"]);
      }
      $cadena .= '"'.$c[$i]["prop"].'":"'.$c[$i]["valor"].'"';
      $proximo = $i + 1;
      if($c[$proximo]["tipo"]=="col"){
        if($indice==$c[$proximo]["indice"]){
          $cadena .= ",";
        } else {
          $cadena .= "},";
        }
      } else {
        $cadena .= "}";
      }
    }
  }
  $cadena .= '],';
  print $cadena;
  //
  $rows = '"rows": [{"c":[';
  $col = 0;
  for($i=0; $i<count($c); $i++){
    $id = $c[$i]["id"];
    $tipo = $c[$i]["tipo"];
    $indice = $c[$i]["indice"];
    if($tipo=="row"){
      $rows .= '{"v":';
      if($t[$col]=="string"){
        $rows.='"'.$c[$i]["valor"].'"}';
      }
      if($t[$col]=="number"){
        $rows.=$c[$i]["valor"];
      }
      $col++;
      if($col==count($t)){
        $col = 0;
        $rows .= '}]}';
        //
        $proximo=$i+1;
        if($proximo<count($c)){
          $rows .= ',{"c":[';
        }
        //
      } else {
        $rows .= ',';
      }
    }
  }
  $rows .= "]}";
  print $rows;
?>